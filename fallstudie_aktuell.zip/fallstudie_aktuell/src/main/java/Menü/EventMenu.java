package Menü;

public interface EventMenu {
    public void selected(int index);
    
}
